from email.policy import default
from stringprep import map_table_b2
import pygame
import pytmx
import pyscroll
from player import Player
from map import MapManager
from dialog import DialogBox

pygame.init()

class Game :
        def __init__(self):
                # creer la fenetre de jeu
                pygame.display.set_caption("Jeu") 
                self.screen = pygame.display.set_mode((1280, 720))
                
                #generer le joueur
                self.player = Player()
                self.map_manager = MapManager(self.screen, self.player)
                self.dialog_box = DialogBox()
                
                  
        def handle_input(self):
                pressed = pygame.key.get_pressed()
                
                if pressed[pygame.K_UP]:
                        self.player.move_up()
                elif pressed[pygame.K_DOWN]:
                        self.player.move_down() 
                elif pressed[pygame.K_LEFT]:
                        self.player.move_left()
                elif pressed[pygame.K_RIGHT]:
                        self.player.move_right()
                        
                elif pressed[pygame.K_z]:
                        self.player.move_up()
                elif pressed[pygame.K_s]:
                        self.player.move_down() 
                elif pressed[pygame.K_q]:
                        self.player.move_left()
                elif pressed[pygame.K_d]:
                        self.player.move_right()
                        
        
        def update(self):
                self.map_manager.update()

        
        def run(self):
                
                clock = pygame.time.Clock()
                
                run = True
                while run:
                        self.player.save_location()
                        self.handle_input()
                        self.update()
                        self.map_manager.draw()
                        self.dialog_box.render(self.screen)
                        pygame.display.flip()
                        for event in pygame.event.get():
                                if event.type == pygame.QUIT:
                                        run = False
                                elif event.type == pygame.KEYDOWN:
                                        if event.key == pygame.K_SPACE:
                                                self. map_manager.check_npc_collisions(self.dialog_box)
                        clock.tick(60)

                pygame.display.update()

                pygame.quit()
                quit()