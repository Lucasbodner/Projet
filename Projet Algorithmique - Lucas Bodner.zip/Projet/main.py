from turtle import back, position
from game import Game
import pygame
import pytmx
import pyscroll

class Main :
        if __name__ == '__main__':
                pygame.init()
                game = Game()  
                game.run()