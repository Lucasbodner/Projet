<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Nature " tilewidth="16" tileheight="16" tilecount="720" columns="40">
 <image source="Nature.png" trans="000000" width="641" height="288"/>
</tileset>
